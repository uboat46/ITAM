#pragma once

int main_planos(int argc, char** argv);

