#pragma once
int main_reinas(int argc, char** argv);
