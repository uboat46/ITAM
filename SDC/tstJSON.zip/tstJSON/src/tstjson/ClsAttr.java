/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tstjson;

/**
 *
 * @author uboat
 */
public class ClsAttr {
    private int attrInt = 0;
    private double[] attrDoubleArr = null;
    
    public ClsAttr() {
    }

    public int getAttrInt() {
        return attrInt;
    }

    public void setAttrInt(int attrInt) {
        this.attrInt = attrInt;
    }

    public double[] getAttrDoubleArr() {
        return attrDoubleArr;
    }

    public void setAttrDoubleArr(double[] attrDoubleArr) {
        this.attrDoubleArr = attrDoubleArr;
    }
    
    
}
